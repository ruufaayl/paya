# Rupay: CS3017 final submission

**Course:** CS3017 Enterprise Systems & Applications, Fall 2026

**Team:** Rufayl Waseem (24i-5660) · Taha Ali (24i-5525) · Harris Safi (24i-5652) · Kanz ur Rehman (24i-5544) · Mudaser Waleed (24i-5681) · Ateeq Riaz (roll no. to add)

**Project:** Rupay, *dedo mujhay!* A wallet to pay any shop by Raast QR or send money to any bank account in Pakistan. The shop sees PAID only when the money has really arrived.

Student prototype: synthetic data only, simulated Raast rail and simulated bank directory, no real money.

## Live links

| What | Link |
|---|---|
| Live app (start page) | https://paya-six.vercel.app/ |
| Customer wallet and tills (phone) | https://paya-six.vercel.app/app |
| Send to a bank | https://paya-six.vercel.app/app/send |
| Mission Control (staff console) | https://paya-six.vercel.app/control |
| API reference | https://paya-six.vercel.app/docs |
| Source code (GitHub) | https://github.com/ruufaayl/paya |

Demo password for every account: `paya-demo-2026`. Staff accounts are named after the team: `rufayl.finance`, `taha.audit`, `harris.compliance`, `kanz.compliance`, `mudaser.ops`, `ateeq.ops`.

## What is in this folder (brief §10)

| Folder | Deliverable |
|---|---|
| 01-Architecture-Brief | Architecture brief, 2 pages (PDF and Word) |
| 02-Design-Dossier | Architecture and design dossier, 4,947 words (PDF and Word) |
| 03-Review-Deck | Architecture review deck, 10 slides (PDF) |
| 04-Technical-Demo | Demo script (10 min) and full live showcase (15 min) |
| 05-Engineering-Evidence | Tests (159 passing), API run, load test, crash drill, logs, screenshots, AI evaluation, rehearsal (9/9 scenes). Start with 00-evidence-index.pdf |
| 06-Individual-Viva | Common core plus one pack per member (A to F) |
| 07-Source-Code | The repository at commit 47d7e3a (evidence and built PDFs are in folders 01–05; everything is also on GitHub) |
| 08-Gate-Pack-and-AI-Log | Gate pack (where each brief requirement is evidenced) and the AI use log |
